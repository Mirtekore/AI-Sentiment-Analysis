// component
import Iconify from '../../components/Iconify';

// ----------------------------------------------------------------------

const getIcon = (name) => <Iconify icon={name} width={22} height={22} />;

const sidebarConfig = [
  {
    title: 'Charts',
    path: '/COMP90024_Group54/dashboard',
    icon: getIcon('eva:pie-chart-2-fill')
  },
  {
    title: 'Map',
    path: '/COMP90024_Group54/map',
    icon: getIcon('eva:map-fill')
  },

];

export default sidebarConfig;
