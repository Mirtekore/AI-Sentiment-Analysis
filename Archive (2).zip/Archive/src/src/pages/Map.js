import { 
  Container,
  Button, 
  Grid, 
  Card, 
  CardHeader, 
  Box, 
  CardMedia,
  CardActions, 
  CardContent,
  Typography
} from "@mui/material";

import { Link } from 'react-router-dom'
import Page from '../components/Page';

export default function Map() {

  return (
    <Page title="Map | COMP90024-Group 54">
      <Container maxWidth="xl">
  
        <Grid container spacing={2}>
          
          <Grid item xs={12} md={6} lg={12}>
            <Card>
              <CardHeader title="Twitter Activity Map of Australia"  />
              <Box sx={{ p: 3, pb: 1 }} dir="ltr">

                <CardMedia 
                  component="img" 
                  style={{ width: '50%', height: '50%', objectFit: 'cover', margin: 'auto' }}
                  image={ require("../_mock/maps/point.png") }
                />

                <CardContent> 
                  <Typography variant="body2" color="text.secondary"> 
                  This map displays the distribution of Twitter activity locations related to AI across Australia, allowing us to observe the level of user engagement in AI discussions in different regions of Australia.
                  </Typography> 
                </CardContent>  
                
                <CardActions style={{ justifyContent: 'space-between' }}>
                  <Button component={Link} to={"/scenario1"}>see the whole map</Button>
                </CardActions>
              </Box>
            </Card>
          </Grid>
  
          <Grid item xs={12} md={6} lg={6}>
            <Card>
              <CardHeader title="Twitter Relationship Map between Australian Education"  />
              <Box sx={{ p: 3, pb: 1 }} dir="ltr">

                 <CardMedia 
                  component="img" 
                  style={{ width: '50%', height: '50%', objectFit: 'cover', margin: 'auto' }}                  justify="center"
                  image={ require("../_mock/maps/edu_num_tweets.png") }
                />

              <CardContent> 
                <Typography variant="body2" color="text.secondary"> 
                  This map presents the distribution data of Australian education and the spatial distribution of AI-related tweets in Australia.
                </Typography> 
              </CardContent>  
  
              <CardActions style={{ justifyContent: 'space-between' }}>
                <Button component={Link} to={"/scenario2"}>see the whole map</Button>
              </CardActions>
            
            </Box>
            </Card>
          </Grid>
  
          <Grid item xs={12} md={6} lg={6}>
            <Card>
              <CardHeader title="Twitter Relationship Map between Australian Economy"  />
               <Box sx={{ p: 3, pb: 1 }} dir="ltr">
                 
                 <CardMedia 
                  component="img" 
                  style={{ width: '50%', height: '50%', objectFit: 'cover', margin: 'auto' }}                  justify="center"
                  image={ require("../_mock/maps/eco_num_tweets.png") }
                />          

                <CardContent> 
                  <Typography variant="body2" color="text.secondary"> 
                  This map presents the distribution data of Australian edconomy and the spatial distribution of AI-related tweets in Australia.
                  </Typography> 
                </CardContent>  
    
                <CardActions style={{ justifyContent: 'space-between' }}>
                  <Button component={Link} to={"/scenario3"}>see the whole map</Button>
                </CardActions>
               
               </Box>
            </Card>
          </Grid>
          

        </Grid>
      </Container>
    </Page>
  );
}
