var mapConfig1 = {
  "version": "v1",
  "config": {
    "visState": {
      "filters": [],
      "layers": [
        {
          "id": "4vmg733",
          "type": "geojson",
          "config": {
            "dataId": "melbourne_twitter",
            "label": "Melbourne Tweets Dataset",
            "color": [
              250,
              194,
              0
            ],
            "highlightColor": [
              252,
              242,
              26,
              255
            ],
            "columns": {
              "geojson": "_geojson"
            },
            "isVisible": true,
            "visConfig": {
              "opacity": 0.8,
              "strokeOpacity": 0.8,
              "thickness": 0.5,
              "strokeColor": null,
              "colorRange": {
                "name": "ColorBrewer YlOrRd-6",
                "type": "sequential",
                "category": "ColorBrewer",
                "colors": [
                  "#ffffb2",
                  "#fed976",
                  "#feb24c",
                  "#fd8d3c",
                  "#f03b20",
                  "#bd0026"
                ]
              },
              "strokeColorRange": {
                "name": "ColorBrewer YlOrRd-6",
                "type": "sequential",
                "category": "ColorBrewer",
                "colors": [
                  "#ffffb2",
                  "#fed976",
                  "#feb24c",
                  "#fd8d3c",
                  "#f03b20",
                  "#bd0026"
                ]
              },
              "radius": 15,
              "sizeRange": [
                0,
                10
              ],
              "radiusRange": [
                0,
                20
              ],
              "heightRange": [
                0,
                500
              ],
              "elevationScale": 5,
              "enableElevationZoomFactor": true,
              "stroked": true,
              "filled": true,
              "enable3d": false,
              "wireframe": false
            },
            "hidden": false,
            "textLabel": [
              {
                "field": null,
                "color": [
                  255,
                  255,
                  255
                ],
                "size": 18,
                "offset": [
                  0,
                  0
                ],
                "anchor": "start",
                "alignment": "center"
              }
            ]
          },
          "visualChannels": {
            "colorField": {
              "name": "sentiment",
              "type": "real"
            },
            "colorScale": "quantile",
            "strokeColorField": {
              "name": "sentiment",
              "type": "real"
            },
            "strokeColorScale": "quantile",
            "sizeField": null,
            "sizeScale": "linear",
            "heightField": null,
            "heightScale": "linear",
            "radiusField": null,
            "radiusScale": "linear"
          }
        }
      ],
      "interactionConfig": {
        "tooltip": {
          "fieldsToShow": {
            "melbourne_twitter": [
              {
                "name": "time",
                "format": null
              },
              {
                "name": "sentiment",
                "format": null
              }
            ]
          },
          "compareMode": false,
          "compareType": "absolute",
          "enabled": true
        },
        "brush": {
          "size": 0.5,
          "enabled": false
        },
        "geocoder": {
          "enabled": false
        },
        "coordinate": {
          "enabled": false
        }
      },
      "layerBlending": "normal",
      "splitMaps": [],
      "animationConfig": {
        "currentTime": null,
        "speed": 1
      }
    },
    "mapState": {
      "bearing": 0,
      "dragRotate": false,
      "latitude": -30.768782733213182,
      "longitude": 145.39167779070814,
      "pitch": 0,
      "zoom": 3.2298210239963554,
      "isSplit": false
    },
    "mapStyle": {
      "styleType": "dark",
      "topLayerGroups": {},
      "visibleLayerGroups": {
        "label": true,
        "road": true,
        "border": false,
        "building": true,
        "water": true,
        "land": true
      },
      "threeDBuildingColor": [
        9.665468314072013,
        17.18305478057247,
        31.1442867897876
      ],
      "mapStyles": {}
    }
  }
}

export default mapConfig1;