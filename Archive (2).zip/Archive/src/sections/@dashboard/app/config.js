const SERVER = "http://172.26.135.240:5984";


export default SERVER;