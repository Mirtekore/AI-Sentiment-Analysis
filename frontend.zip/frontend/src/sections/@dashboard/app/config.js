const SERVER = "http://172.26.135.240:5984";
// const SERVER = "http://127.0.0.1:8000";

export default SERVER;