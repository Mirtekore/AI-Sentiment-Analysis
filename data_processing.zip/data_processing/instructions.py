output_data = []

vocab_list = ["chatgpt",
    "openai",
    "dalle",
    "dall e",
    " ai ",
    "#ai",
    "a\.i\.",
    "artificial intelligence",
    "machine learning",
    "neural network",
    "natural language processing",
    "computer vision",
    "deep learning",
    "unsupervised learning",
    "supervised learning",
    "reinforcement learning",
    "sentiment analysis",
    " nlp ",
    "#nlp",
    " gpt ",
    "#gpt",
    " agi ",
    "#agi",
    "midjourney",
    "stable diffusion",
    "stablediffusion",
    "starryai",
    "nightcafe",
    "craiyon",
    "jasper art",
    "#promptsharing",
    "prompt engineer",
    "#promptengineering",
    "#aicommunity",
    "google bard",
    "anthropicAI",
    "PaLM-2",
    "bardai",
    " LLM ",
    "large language model",
    "generativeai",
    "generative AI",
    "chatbot",
    "deepmind",
    "diffusion model",
    "FinOps",
    "virtualassistant",
    "selfdrivingcar",
    "musiclm",
    "deforum",
    "so-vits-svc",
     "notion ai",
      "notionai",
      "newbing",
      "copilot"
  ]

import json

json_file_name = 
data = []
# depends on the system RAM
start = 0
end = 100000
with open(json_file_name, 'r', encoding='utf-8') as f:
    next(f)  # skip header line
    i = 0
    for line in f:
        if i < start:
            i += 1
            continue
        elif i >= end:
            continue
        stripped_line = line.rstrip(',\n')
        
        try:
            data.append(json.loads(stripped_line))
            i += 1
        except json.JSONDecodeError as e:
            print(f'Error decoding line: {stripped_line}')
            print(f'Error: {e}')
data = data[:-1]
import re

for d in data:
    obj = d['doc']
    temp_dict = {}
    text = obj['data']['text']
    for v in vocab_list:
        if re.findall(v, text.lower()):
            temp_dict = {'id' : obj['_id'], 'time': obj['data']['created_at'], 'geo': obj['includes']['places'][0]['geo'], 'sentiment': obj['data']['sentiment'], 'text': text, 'matched_word': v}
            output_data.append(temp_dict)
            break
    
import geopandas as gpd
from shapely.geometry import Point, Polygon

points_df = gpd.read_file()

polygons_df = gpd.read_file()

points_df = points_df.to_crs(polygons_df.crs)

points_in_polygons = gpd.sjoin(points_df, polygons_df, how='inner', predicate='within')

grouped_df = points_in_polygons.groupby('feature_name')

group_sizes = grouped_df.size().reset_index(name='num_tweets')
polygons_df = polygons_df.merge(group_sizes, on='feature_name', how='left')
polygons_df['num_tweets'] = polygons_df['num_tweets'].fillna(0)
group_mean = grouped_df.mean('sentiment')['sentiment'].reset_index(name='sentiment')
polygons_df = polygons_df.merge(group_mean, on='feature_name', how='left')
polygons_df['sentiment'] = polygons_df['sentiment'].fillna(0)
polygons_df['edu_indicator'] = (polygons_df['tert_uni_other_high_edu_tot_p'] + polygons_df['tert_voc_edu_tot_p'] + polygons_df['other_type_educ_instit_tot_p']) / polygons_df['tot_p'].max()
polygons_df['num_neg'] = polygons_df['feature_name'].map(grouped_df.apply(lambda x: (x['sentiment'] < 0).sum()))
polygons_df['num_pos'] = polygons_df['feature_name'].map(grouped_df.apply(lambda x: (x['sentiment'] > 0).sum()))
polygons_df['num_neu'] = polygons_df['feature_name'].map(grouped_df.apply(lambda x: (x['sentiment'] == 0).sum()))
polygons_df['num_neg'] = polygons_df['num_neg'].fillna(0)
polygons_df['num_pos'] = polygons_df['num_pos'].fillna(0)
polygons_df['num_neu'] = polygons_df['num_neu'].fillna(0)

polygons_df[['feature_name', 'num_tweets', 'sentiment', 'edu_indicator', 'num_neg', 'num_pos', 'num_neu']].to_json('/content/drive/MyDrive/ccc_data/outputmap_edu.json', orient='records')

polygons_df.to_file("/output_edu.geojson", driver='GeoJSON')

points_df = gpd.read_file()

polygons_df = gpd.read_file()

points_df = points_df.to_crs(polygons_df.crs)

points_in_polygons = gpd.sjoin(points_df, polygons_df, how='inner', predicate='within')

grouped_df = points_in_polygons.groupby('feature_name')

group_sizes = grouped_df.size().reset_index(name='num_tweets')
polygons_df = polygons_df.merge(group_sizes, on='feature_name', how='left')
polygons_df['num_tweets'] = polygons_df['num_tweets'].fillna(0)
group_mean = grouped_df.mean('sentiment')['sentiment'].reset_index(name='sentiment')
polygons_df = polygons_df.merge(group_mean, on='feature_name', how='left')
polygons_df['sentiment'] = polygons_df['sentiment'].fillna(0)

polygons_df.to_file("output_eco.geojson", driver='GeoJSON')

