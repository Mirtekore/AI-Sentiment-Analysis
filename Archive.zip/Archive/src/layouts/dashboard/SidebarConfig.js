// component
import Iconify from '../../components/Iconify';

// ----------------------------------------------------------------------

const getIcon = (name) => <Iconify icon={name} width={22} height={22} />;

const sidebarConfig = [
  {
    title: 'Popularity',
    path: '/COMP90024_Group54/dashboard',
    icon: getIcon('eva:people-fill')
  },
  {
    title: 'Sentiment',
    path: '/COMP90024_Group54/sentiment',
    icon: getIcon('eva:pie-chart-2-fill')
  },
  {
    title: 'Distribution',
    path: '/COMP90024_Group54/map',
    icon: getIcon('eva:map-fill')
  },
  {
    title: 'Education',
    path: '/COMP90024_Group54/edu',
    icon: getIcon('eva:map-fill')
  },
  {
    title: 'Economy',
    path: '/COMP90024_Group54/eco',
    icon: getIcon('eva:map-fill')
  },

];

export default sidebarConfig;
