// material
import { Box, Grid, Container, Typography } from '@mui/material';

// components
import Page from '../components/Page';
import {
  LineChart,
  PieChart,
  PieChart2
} from '../sections/@dashboard/app';


// ----------------------------------------------------------------------

export default function DashboardApp() {
  

  return (
    <Page title="Dashboard | COMP90024-Group 54">
      <Container maxWidth="xl">
        <Box sx={{ pb: 5 }}>
          <Typography variant="h4"> COMP90024 Group54</Typography>
        </Box>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={12}>
              <LineChart />
              <Typography variant="body1" align="center">
              As time progresses, an increasing number of users are discussing AI-related topics on Twitter. In order to understand what factors have led to a growing number of people discussing AI and whether the sentiment during these discussions is positive or negative, we have analyzed the Twitter data we collected and compared it with the distribution of education and economy data in Australia.
            </Typography>
            </Grid>
          
          
        </Grid>
      </Container>
    </Page>
  );
}
