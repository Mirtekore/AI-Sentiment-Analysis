// material
import { Box, Grid, Container, Typography } from '@mui/material';

// components
import Page from '../components/Page';
import {
  PieChart,
  PieChart2
} from '../sections/@dashboard/app';


// ----------------------------------------------------------------------

export default function Sentiment() {
  

  return (
    <Page title="Sentiment | COMP90024-Group 54">
      <Container maxWidth="xl">
        <Box sx={{ pb: 5 }}>
          <Typography variant="h4"> COMP90024 Group54</Typography>
        </Box>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6} lg={6}>
            <PieChart />
          </Grid>     

          <Grid item xs={12} md={6} lg={6}>
            <PieChart2 />
          </Grid>
          
        </Grid>
      </Container>
    </Page>
  );
}
