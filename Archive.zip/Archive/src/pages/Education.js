import { 
    Container,
    Button, 
    Grid, 
    Card, 
    CardHeader, 
    Box, 
    CardMedia,
    CardActions, 
    CardContent,
    Typography
  } from "@mui/material";
  
  import { Link } from 'react-router-dom'
  import Page from '../components/Page';
  
  export default function Map() {
  
    return (
      <Page title="Education | COMP90024-Group 54">
        <Container maxWidth="xl">
    
          <Grid container spacing={2}>
            
            
          
            <Grid item xs={12} md={6} lg={12}>
            <Card>
              <CardHeader title="Education Distribution Map of Australia"  />
              <Box sx={{ p: 3, pb: 1 }} dir="ltr">

                <CardMedia 
                  component="img" 
                  style={{ width: '50%', height: '50%', objectFit: 'cover', margin: 'auto' }}
                  image={ require("../_mock/maps/edu_num_tweets.png") }
                />

                <CardContent> 
                  <Typography variant="body2" color="text.secondary"> 
                  This map displays the distribution of Education in Austrialia
                  </Typography> 
                </CardContent>  
                
                <CardActions style={{ justifyContent: 'space-between' }}>
                  <Button component={Link} to={"/scenario2"}>see the whole map</Button>
                </CardActions>
              </Box>
            </Card>
          </Grid>
    
           
  
          </Grid>
        </Container>
      </Page>
    );
  }
  