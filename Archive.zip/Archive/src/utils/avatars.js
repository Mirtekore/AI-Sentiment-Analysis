// ----------------------------------------------------------------------

export const imgAvatar = (index) => `/static/images/avatars/${index}.png`;
