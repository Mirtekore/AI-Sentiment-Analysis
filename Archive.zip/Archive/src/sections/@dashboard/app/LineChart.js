import React, {useEffect, useState} from 'react';
import ReactECharts from 'echarts-for-react';
import { styled } from '@mui/material/styles';
import { Card, CardHeader} from '@mui/material';
import * as echarts from 'echarts';


const CHART_HEIGHT = 450;
const LEGEND_HEIGHT = 72;

const ChartWrapperStyle = styled('div')(({ theme }) => ({
  height: CHART_HEIGHT+50,
  marginTop: theme.spacing(2),
  marginBottom: theme.spacing(5),
  '& .apexcharts-canvas svg': {
    height: CHART_HEIGHT
  },
  '& .apexcharts-canvas svg,.apexcharts-canvas foreignObject': {
    overflow: 'visible'
  },
  '& .apexcharts-legend': {
    height: LEGEND_HEIGHT,
    alignContent: 'center',
    position: 'relative !important',
    borderTop: `solid 1px ${theme.palette.divider}`,
    top: `calc(${CHART_HEIGHT - LEGEND_HEIGHT}px) !important`
  }
}));

export default function LineChart() {
  const [chartData, setData ] = useState([]);

  const [chartDate, setDate ] = useState([]);
  useEffect(() => {
    fetch('http://172.26.135.240:5984/popularity/data/',
      {headers: {
        'Authorization': 'Basic ' + btoa('admin:Zi12ZnK2r2n')
      }, method: 'GET',
    }).then(
      response => response.json()
    ).then(
      data => {
        let chartData = [];  
        let chartDate = []
        for (const key in data['date_count']) {

          chartData.push(data['date_count'][key]);
          chartDate.push(key);

        }
        setDate(chartDate);
        setData(chartData);     
       }
    );
  }, []);

  const options = {
    tooltip: {
      trigger: 'axis',
      position: function (pt) {
        return [pt[0], '10%'];
      }
    },
    title: {
      left: 'center',
    },
    toolbox: {
      feature: {
        dataZoom: {
          yAxisIndex: 'none'
        },
        restore: {},
        saveAsImage: {}
      }
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: chartDate
    },
    yAxis: {
      type: 'value',
      boundaryGap: [0, '100%']
    },
    dataZoom: [
      {
        type: 'inside',
        start: 0,
        end: 10
      },
      {
        start: 0,
        end: 10
      }
    ],
    series: [
      {
        name: 'Tweet Counts (About AI)',
        type: 'line',
        symbol: 'none',
        sampling: 'lttb',
        itemStyle: {
          color: 'rgb(255, 70, 131)'
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            {
              offset: 0,
              color: 'rgb(255, 158, 68)'
            },
            {
              offset: 1,
              color: 'rgb(255, 70, 131)'
            }
          ])
        },
        data: chartData
      }
    ]
  };


  return (
    <Card>
      <CardHeader title="Daily Tweets" />
        <ChartWrapperStyle dir="ltr">
        <ReactECharts option={options} notMerge={true} style={{height: "100%"}}/>
        </ChartWrapperStyle>
    </Card>
  )

}
