// import React, {useEffect, useState} from 'react';
var headers = new Headers({
    'Authorization': `Basic ${btoa("admin" + ':' + "Zi12ZnK2r2n")}`
});


// const [chartData, setChartData ] = useState([]);

const CHART_DATA = []; 

fetch('http://172.26.135.240:5984/geo/_design/myview/_view/sentiment?group=true',  {headers: {
  'Cookie': 'AuthSession=YWRtaW46NjQ2QjgxQTg6yYKrhdJSt-868DDH2ed2ZssjvaY'}, 
  method: 'GET' })
  .then(response => response.json()) 
  .then(
    data => {  
        console.log(data) ; 

        console.log(data['rows']) ; 

        data['rows'].forEach(item => {
            const key = item.key;
            const value = item.value;
            console.log(key)
            CHART_DATA.push({value: value, name: key});
          });


        // data['rows'].data.map((v) => {
        //   CHART_DATA.push({value: v[1], name: v[0]});
        //   return null;
        // }); 
        console.log(CHART_DATA)
        
      })
//   .then(
//     json => console.log(json)
//   )
  .catch(err => console.log('Request Failed', err));



